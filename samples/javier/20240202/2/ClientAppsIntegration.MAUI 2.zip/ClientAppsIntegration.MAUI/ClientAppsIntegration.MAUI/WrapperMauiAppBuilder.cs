﻿#nullable disable
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Diagnostics.Metrics;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace ClientAppsIntegration.MAUI
{
    public class WrapperMauiAppBuilder : IHostApplicationBuilder
    {
        readonly MauiAppBuilder _appBuilder;

        public WrapperMauiAppBuilder(MauiAppBuilder appBuilder)
        {
            _appBuilder = appBuilder;
        }

        public IConfigurationManager Configuration => _appBuilder.Configuration;

        public IHostEnvironment Environment => new MauiHostEnvironment();

        public ILoggingBuilder Logging => _appBuilder.Logging;

        public IMetricsBuilder Metrics => null;

        public IDictionary<object, object> Properties => throw new NotImplementedException();

        public IServiceCollection Services => _appBuilder.Services;

        public void ConfigureContainer<TContainerBuilder>(IServiceProviderFactory<TContainerBuilder> factory, Action<TContainerBuilder> configure = null) where TContainerBuilder : notnull
        {
            _appBuilder.ConfigureContainer<TContainerBuilder>(factory, configure);
        }

        public MauiApp Build()
        {
            return _appBuilder.Build();
        }

        //public IHost Build()
        //{
        //    _appBuilder.Build();

        //    using DiagnosticListener diagnosticListener = HostBuilder.LogHostBuilding(this);
        //    _hostBuilderAdapter?.ApplyChanges();

        //    _appServices = _createServiceProvider();

        //    // Prevent further modification of the service collection now that the provider is built.
        //    _serviceCollection.MakeReadOnly();

        //    var appHost = new HostBuilder();
        //    appHost.ConfigureDefaults
        //    appHost.Start();
        //    return Microsoft.Extensions.Hosting.HostBuilder.ResolveHost(_appServices, diagnosticListener);
        //}
    }

    internal class MauiHostEnvironment : IHostEnvironment
    {
        public string ApplicationName { get; set; } = typeof(MauiHostEnvironment).Assembly.GetName().Name;

        public IFileProvider ContentRootFileProvider { get; set; } = new PhysicalFileProvider(AppContext.BaseDirectory);
        
        public string ContentRootPath { get; set; } = AppContext.BaseDirectory;

        public string EnvironmentName { get; set; } = "Development";
    }
}
﻿using Foundation;

namespace ClientAppsIntegration.MAUI
{
    [Register("AppDelegate")]
    public class AppDelegate : MauiAspireUIApplicationDelegate
    {

    }
}